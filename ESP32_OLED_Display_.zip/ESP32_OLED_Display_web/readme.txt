這個程式包含以下功能：
網頁介面：
美觀的使用者介面，包含輸入框和發送按鈕
即時顯示發送狀態（成功/失敗）
響應式設計，適合各種螢幕大小
ESP32 功能：
WiFi 連接功能
網頁伺服器
OLED 顯示控制
要使用這個程式，您需要：
安裝必要的 Arduino 程式庫：
Adafruit GFX Library
Adafruit SSD1306
ESP32 WebServer
WiFi
修改程式碼中的 WiFi 設定：
Apply to c_cpp_proper...
將程式上傳到 ESP32 後：
ESP32 會自動連接到指定的 WiFi 網路
在序列監視器中會顯示 ESP32 的 IP 位址
在瀏覽器中輸入該 IP 位址即可訪問控制介面
使用方法：
在網頁介面的輸入框中輸入想要顯示的文字
點擊「發送到 OLED」按鈕
文字會立即顯示在 OLED 螢幕上
網頁會顯示發送狀態（成功/失敗）
您需要先在 Arduino IDE 中安裝必要的程式庫，然後將程式上傳到 ESP32。